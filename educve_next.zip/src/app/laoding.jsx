export default function Loading() {
  return (
    <div className="td_preloader">
      <div className="td_preloader_in">
        <span />
        <span />
      </div>
    </div>
  );
}
